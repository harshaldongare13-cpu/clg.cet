
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getSettings, saveSettings } from '../../store';
import { SiteSettings } from '../../types';

interface AdminSettingsProps {
  onUpdate: () => void;
}

const AdminSettings: React.FC<AdminSettingsProps> = ({ onUpdate }) => {
  const navigate = useNavigate();
  const [settings, setSettings] = useState<SiteSettings>(getSettings());

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const value = e.target.type === 'checkbox' ? (e.target as HTMLInputElement).checked : e.target.value;
    setSettings({ ...settings, [e.target.name]: value });
  };

  const handleSave = () => {
    saveSettings(settings);
    onUpdate();
    alert('Settings saved successfully!');
    navigate('/admin');
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={() => navigate('/admin')} className="text-blue-600 hover:underline">← Dashboard</button>
        <h1 className="text-3xl font-bold text-slate-900">Theme Customization</h1>
      </div>

      <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-slate-200 space-y-10">
        <section className="space-y-6">
          <h2 className="text-xl font-bold border-b pb-4">Branding & Colors</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Primary Color</label>
              <div className="flex gap-4 items-center">
                <input 
                  type="color" 
                  name="primaryColor" 
                  value={settings.primaryColor} 
                  onChange={handleChange} 
                  className="h-12 w-20 p-1 bg-slate-50 rounded border border-slate-200 cursor-pointer"
                />
                <input 
                  type="text" 
                  name="primaryColor" 
                  value={settings.primaryColor} 
                  onChange={handleChange} 
                  className="flex-grow bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <p className="text-xs text-slate-400 mt-2">This color will be applied to buttons, links, and active states.</p>
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Primary Font</label>
              <select 
                name="fontFamily" 
                value={settings.fontFamily} 
                onChange={handleChange}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Inter">Inter (Default)</option>
                <option value="Roboto">Roboto</option>
                <option value="Open Sans">Open Sans</option>
                <option value="serif">System Serif</option>
              </select>
            </div>
          </div>
        </section>

        <section className="space-y-6">
          <h2 className="text-xl font-bold border-b pb-4">Layout Options</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Container Width</label>
              <select 
                name="containerWidth" 
                value={settings.containerWidth} 
                onChange={handleChange}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="narrow">Narrow (640px)</option>
                <option value="normal">Normal (1024px)</option>
                <option value="wide">Wide (1280px)</option>
              </select>
            </div>
            <div className="flex items-center gap-3 pt-8">
              <input 
                type="checkbox" 
                name="showSidebarOnDetails" 
                id="showSidebarOnDetails"
                checked={settings.showSidebarOnDetails} 
                onChange={handleChange}
                className="w-5 h-5 accent-blue-600"
              />
              <label htmlFor="showSidebarOnDetails" className="text-sm font-bold text-slate-700">Show Sidebar on College Details</label>
            </div>
          </div>
        </section>

        <div className="pt-6">
          <button 
            onClick={handleSave}
            className="w-full bg-slate-900 text-white font-bold py-4 rounded-xl hover:bg-slate-800 transition shadow-lg"
          >
            Apply Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;

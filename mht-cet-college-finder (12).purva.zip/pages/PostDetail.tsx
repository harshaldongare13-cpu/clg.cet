
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Post } from '../types';
import { getPosts } from '../store';

const PostDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<Post | null>(null);

  useEffect(() => {
    const all = getPosts();
    const found = all.find(p => p.slug === slug);
    setPost(found || null);
  }, [slug]);

  if (!post) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <h1 className="text-2xl font-bold mb-4">Post Not Found</h1>
        <Link to="/blog" className="text-blue-600 hover:underline">Back to Blog</Link>
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen py-16 px-4">
      <article className="max-w-3xl mx-auto">
        <nav className="mb-8 text-sm text-slate-500">
          <Link to="/" className="hover:text-blue-600">Home</Link>
          <span className="mx-2">/</span>
          <Link to="/blog" className="hover:text-blue-600">Blog</Link>
          <span className="mx-2">/</span>
          <span className="text-slate-900">{post.title}</span>
        </nav>

        <header className="mb-12">
          <time className="text-blue-600 font-bold uppercase tracking-widest text-xs">{post.date}</time>
          <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mt-4 leading-tight">
            {post.title}
          </h1>
          <p className="text-xl text-slate-500 mt-6 leading-relaxed italic">
            {post.excerpt}
          </p>
        </header>

        <div className="prose prose-blue prose-lg max-w-none text-slate-700 leading-relaxed space-y-6">
          {post.content.split('\n').map((para, i) => (
            <p key={i}>{para}</p>
          ))}
        </div>

        <footer className="mt-16 pt-8 border-t border-slate-100">
          <div className="flex justify-between items-center">
            <Link to="/blog" className="text-blue-600 font-bold hover:underline flex items-center gap-2">
              ← Back to all posts
            </Link>
            <div className="flex gap-4">
              <button className="text-slate-400 hover:text-blue-600">Share</button>
            </div>
          </div>
        </footer>
      </article>
    </div>
  );
};

export default PostDetail;

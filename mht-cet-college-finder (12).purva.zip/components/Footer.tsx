
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="space-y-4">
          <h3 className="text-2xl font-bold text-white">MHT-CET Finder</h3>
          <p className="text-sm leading-relaxed">
            Leading portal for students seeking engineering and pharmacy education in Maharashtra. We provide up-to-date information on colleges in Nagpur, Pune, and Mumbai.
          </p>
        </div>
        
        <div className="space-y-4">
          <h4 className="text-lg font-semibold text-white">Quick Links</h4>
          <ul className="space-y-2">
            <li><Link to="/" className="hover:text-blue-400 transition">Home</Link></li>
            <li><Link to="/finder" className="hover:text-blue-400 transition">College Finder</Link></li>
            <li><Link to="/about" className="hover:text-blue-400 transition">About Us</Link></li>
            <li><Link to="/blog" className="hover:text-blue-400 transition">Blog Updates</Link></li>
          </ul>
        </div>

        <div className="space-y-4">
          <h4 className="text-lg font-semibold text-white">Contact Info</h4>
          <ul className="space-y-2 text-sm">
            <li>Email: info@mhtcetfinder.edu.in</li>
            <li>Phone: +91 9876543210</li>
            <li>Location: Nagpur, Maharashtra, India</li>
          </ul>
        </div>

        <div className="space-y-4">
          <h4 className="text-lg font-semibold text-white">Social Connect</h4>
          <div className="flex space-x-4">
            <span className="w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center cursor-pointer hover:bg-blue-600 transition">FB</span>
            <span className="w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center cursor-pointer hover:bg-blue-400 transition">TW</span>
            <span className="w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center cursor-pointer hover:bg-pink-600 transition">IG</span>
            <span className="w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center cursor-pointer hover:bg-red-600 transition">YT</span>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center text-xs space-y-4 md:space-y-0">
        <p>© 2024 MHT-CET College Finder. All rights reserved.</p>
        <p>Disclaimer: This is an informational portal. Please refer to official CET cell websites for final admission processes.</p>
      </div>
    </footer>
  );
};

export default Footer;


import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { College, Post } from '../../types';
import { getColleges, saveColleges, getPosts, savePosts } from '../../store';

const Dashboard: React.FC = () => {
  const [colleges, setColleges] = useState<College[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [activeTab, setActiveTab] = useState<'colleges' | 'posts'>('colleges');

  useEffect(() => {
    setColleges(getColleges());
    setPosts(getPosts());
  }, []);

  const handleDeleteCollege = (id: string) => {
    if (window.confirm('Are you sure you want to delete this college?')) {
      const updated = colleges.filter(c => c.id !== id);
      setColleges(updated);
      saveColleges(updated);
    }
  };

  const handleDeletePost = (id: string) => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      const updated = posts.filter(p => p.id !== id);
      setPosts(updated);
      savePosts(updated);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-900">Admin Dashboard</h1>
            <p className="text-slate-500 mt-1">Manage your platform data and settings</p>
          </div>
          <div className="flex gap-4">
            <Link 
              to="/admin/settings" 
              className="bg-slate-200 text-slate-700 px-6 py-2 rounded-lg font-bold hover:bg-slate-300 transition"
            >
              Theme Settings
            </Link>
            <Link 
              to={activeTab === 'colleges' ? '/admin/college' : '/admin/blog'} 
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-blue-700 transition"
            >
              + Add {activeTab === 'colleges' ? 'College' : 'Post'}
            </Link>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">Total Colleges</span>
            <div className="text-2xl font-bold text-slate-900 mt-1">{colleges.length}</div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">Blog Posts</span>
            <div className="text-2xl font-bold text-slate-900 mt-1">{posts.length}</div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">Districts</span>
            <div className="text-2xl font-bold text-slate-900 mt-1">3</div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">Last Update</span>
            <div className="text-2xl font-bold text-slate-900 mt-1">Today</div>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-200 mb-8">
          <button 
            onClick={() => setActiveTab('colleges')}
            className={`px-8 py-4 font-bold text-sm uppercase tracking-widest transition-all ${activeTab === 'colleges' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Colleges List
          </button>
          <button 
            onClick={() => setActiveTab('posts')}
            className={`px-8 py-4 font-bold text-sm uppercase tracking-widest transition-all ${activeTab === 'posts' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Blog Articles
          </button>
        </div>

        {activeTab === 'colleges' ? (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-6 py-4 font-bold text-slate-600 text-sm">College Name</th>
                  <th className="px-6 py-4 font-bold text-slate-600 text-sm">Stream</th>
                  <th className="px-6 py-4 font-bold text-slate-600 text-sm">District</th>
                  <th className="px-6 py-4 font-bold text-slate-600 text-sm">Year</th>
                  <th className="px-6 py-4 font-bold text-slate-600 text-sm">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {colleges.map(c => (
                  <tr key={c.id} className="hover:bg-slate-50 transition">
                    <td className="px-6 py-4 font-medium text-slate-900">{c.name}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">{c.stream}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">{c.district}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">{c.estYear}</td>
                    <td className="px-6 py-4 space-x-4">
                      <Link to={`/admin/college/${c.id}`} className="text-blue-600 font-semibold hover:underline">Edit</Link>
                      <button onClick={() => handleDeleteCollege(c.id)} className="text-red-600 font-semibold hover:underline">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-6 py-4 font-bold text-slate-600 text-sm">Post Title</th>
                  <th className="px-6 py-4 font-bold text-slate-600 text-sm">Date</th>
                  <th className="px-6 py-4 font-bold text-slate-600 text-sm">Excerpt</th>
                  <th className="px-6 py-4 font-bold text-slate-600 text-sm">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {posts.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50 transition">
                    <td className="px-6 py-4 font-medium text-slate-900">{p.title}</td>
                    <td className="px-6 py-4 text-sm text-slate-500 whitespace-nowrap">{p.date}</td>
                    <td className="px-6 py-4 text-sm text-slate-500 truncate max-w-xs">{p.excerpt}</td>
                    <td className="px-6 py-4 space-x-4">
                      <Link to={`/admin/blog/${p.id}`} className="text-blue-600 font-semibold hover:underline">Edit</Link>
                      <button onClick={() => handleDeletePost(p.id)} className="text-red-600 font-semibold hover:underline">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;

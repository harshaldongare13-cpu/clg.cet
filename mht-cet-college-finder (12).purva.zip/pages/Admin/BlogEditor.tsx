
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Post } from '../../types';
import { getPosts, savePosts } from '../../store';

const BlogEditor: React.FC = () => {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();
  const [formData, setFormData] = useState<Partial<Post>>({
    title: '',
    excerpt: '',
    content: '',
    date: new Date().toISOString().split('T')[0]
  });

  useEffect(() => {
    if (id) {
      const all = getPosts();
      const found = all.find(p => p.id === id);
      if (found) setFormData(found);
    }
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const all = getPosts();
    const slug = formData.title?.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
    
    if (id) {
      const updated = all.map(p => p.id === id ? { ...p, ...formData, slug } as Post : p);
      savePosts(updated);
    } else {
      const newPost = { 
        ...formData, 
        id: Date.now().toString(), 
        slug 
      } as Post;
      savePosts([...all, newPost]);
    }
    navigate('/admin');
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <h1 className="text-3xl font-bold mb-8">{id ? 'Edit Blog Post' : 'Write New Post'}</h1>
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200 space-y-6">
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2">Post Title</label>
          <input required name="title" value={formData.title} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" />
        </div>

        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2">Publish Date</label>
          <input type="date" name="date" value={formData.date} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" />
        </div>

        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2">Excerpt (Short Summary)</label>
          <textarea required name="excerpt" value={formData.excerpt} onChange={handleChange} rows={2} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" />
        </div>

        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2">Full Content</label>
          <textarea required name="content" value={formData.content} onChange={handleChange} rows={12} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm" />
        </div>

        <div className="flex gap-4 pt-6">
          <button type="submit" className="flex-grow bg-slate-900 text-white font-bold py-4 rounded-xl hover:bg-slate-800 transition">Publish Post</button>
          <button type="button" onClick={() => navigate('/admin')} className="px-8 bg-slate-100 text-slate-600 font-bold py-4 rounded-xl hover:bg-slate-200 transition">Cancel</button>
        </div>
      </form>
    </div>
  );
};

export default BlogEditor;


import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { College, Stream, District } from '../../types';
import { getColleges, saveColleges } from '../../store';

const CollegeEditor: React.FC = () => {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();
  const [formData, setFormData] = useState<Partial<College>>({
    name: '',
    stream: Stream.PCM,
    district: District.NAGPUR,
    overview: '',
    address: '',
    estYear: '',
    naac: '',
    contact: '',
    website: '',
    metaTitle: '',
    metaDesc: ''
  });

  useEffect(() => {
    if (id) {
      const all = getColleges();
      const found = all.find(c => c.id === id);
      if (found) setFormData(found);
    }
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const all = getColleges();
    const slug = formData.name?.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
    
    if (id) {
      const updated = all.map(c => c.id === id ? { ...c, ...formData, slug } as College : c);
      saveColleges(updated);
    } else {
      const newCollege = { 
        ...formData, 
        id: Date.now().toString(), 
        slug 
      } as College;
      saveColleges([...all, newCollege]);
    }
    navigate('/admin');
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={() => navigate('/admin')} className="text-blue-600 hover:underline">← Dashboard</button>
        <h1 className="text-3xl font-bold text-slate-900">{id ? 'Edit College' : 'Add New College'}</h1>
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-slate-200 space-y-10">
        <section className="space-y-6">
          <h2 className="text-xl font-bold border-b pb-4">Basic Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label className="block text-sm font-bold text-slate-700 mb-2">College Name</label>
              <input required name="name" value={formData.name} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Stream</label>
              <select name="stream" value={formData.stream} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500">
                <option value={Stream.PCM}>PCM (Engineering)</option>
                <option value={Stream.PCB}>PCB (Pharmacy)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">District</label>
              <select name="district" value={formData.district} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500">
                <option value={District.NAGPUR}>Nagpur</option>
                <option value={District.PUNE}>Pune</option>
                <option value={District.MUMBAI}>Mumbai</option>
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-bold text-slate-700 mb-2">Official Website URL</label>
              <input required name="website" value={formData.website} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" placeholder="https://..." />
            </div>
          </div>
        </section>

        <section className="space-y-6">
          <h2 className="text-xl font-bold border-b pb-4">Institutional Details</h2>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">Overview / Description</label>
            <textarea required name="overview" value={formData.overview} onChange={handleChange} rows={5} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Est. Year</label>
              <input name="estYear" value={formData.estYear} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">NAAC Rating</label>
              <input name="naac" value={formData.naac} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" placeholder="e.g. A++" />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Contact Number</label>
              <input name="contact" value={formData.contact} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">Physical Address</label>
            <input name="address" value={formData.address} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
        </section>

        <section className="space-y-6">
          <h2 className="text-xl font-bold border-b pb-4">SEO Fields</h2>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">SEO Title</label>
            <input name="metaTitle" value={formData.metaTitle} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" placeholder="Meta title for Google" />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">SEO Description</label>
            <textarea name="metaDesc" value={formData.metaDesc} onChange={handleChange} rows={3} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500" placeholder="Brief summary for search results" />
          </div>
        </section>

        <div className="flex gap-4 pt-6">
          <button type="submit" className="flex-grow bg-blue-600 text-white font-bold py-4 rounded-xl hover:bg-blue-700 transition shadow-lg">Save Institution</button>
          <button type="button" onClick={() => navigate('/admin')} className="px-8 bg-slate-100 text-slate-600 font-bold py-4 rounded-xl hover:bg-slate-200 transition">Cancel</button>
        </div>
      </form>
    </div>
  );
};

export default CollegeEditor;
